# Unit tests for model logic

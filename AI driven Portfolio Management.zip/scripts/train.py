# Main training script for the agent

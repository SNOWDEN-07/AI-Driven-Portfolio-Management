# Evaluate trained model and plot results
